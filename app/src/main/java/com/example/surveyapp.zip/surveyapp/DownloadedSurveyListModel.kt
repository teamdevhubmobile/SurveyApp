package com.example.surveyapp

data class DownloadedSurveyListModel(val Sno : String, val name : String, val id : String) {
}