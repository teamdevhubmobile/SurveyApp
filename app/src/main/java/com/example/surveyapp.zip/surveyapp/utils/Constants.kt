package com.example.surveyapp.utils

object Constants {

    const val BaseURl:String="https://zoicraze.com/"

}